function mostrarInfos(){
    var resultado = confirm("Deseja mesmo ver informações desse curso");
    if(resultado == true){
        var x = document.getElementById("ADS").checked;
        if(x == true){
            novaJanela = window.open("paginaads.html","pagina ads", "width = 600 , height = 300");
        }
        var y = document.getElementById("bio").checked;
        if(y == true){
            novaJanela = window.open("paginabio.html","pagina sistemas biomedicos", "width = 600 , height = 300");
        }
        var z = document.getElementById("Projetos").checked;
         if(z == true){
            novaJanela = window.open("paginaproj.html","pagina projetos mecanicos", "width = 600 , height = 300");
        }
        var a = document.getElementById("Logistica").checked;
        if(a == true){
            novaJanela = window.open("paginalog.html","pagina logistica", "width = 600 , height = 300");
        }
        var b = document.getElementById("qualidade").checked;
         if(b == true){
            novaJanela = window.open("paginaquali.html","pagina analise da qualidade", "width = 600 , height = 300");
        }
        var c = document.getElementById("fabricacao").checked;
        if(c == true){
            novaJanela = window.open("paginafabricacao.html","pagina fabricacao", "width = 600 , height = 300");
        }
        
        var d = document.getElementById("manufatura").checked;
        if(d == true){
            novaJanela = window.open("paginamanu.html","pagina manufatura", "width = 600 , height = 300");
        }
        
        var e = document.getElementById("Processos").checked;
        if(e == true){
            novaJanela = window.open("paginaprocessometal.html","pagina processos metalurgicos", "width = 600 , height = 300");
        }
        var f = document.getElementById("mecanica").checked;
        if(f == true){
             novaJanela = window.open("paginaauto.html","pagina mecanica automotiva", "width = 600 , height = 300");
        }
        var g = document.getElementById("Poli").checked;
         if(g == true){
            novaJanela = window.open("paginapoli.html","pagina polimeros", "width = 600 , height = 300");
        }
        
        
    }
}