const fs = require('fs');
const data = fs.readFileSync('file.txt');
//Execução é bloqueada até o arquivo ser lido
console.log(data.toString());