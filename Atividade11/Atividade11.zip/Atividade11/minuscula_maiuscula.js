        function maiuscula() {
                document.getElementById("idNome").style.textTransform = "uppercase"; 
        }
        function minuscula(){
                document.getElementById("idNome").style.textTransform = "lowercase";
        }